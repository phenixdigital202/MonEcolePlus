-- Programmatic SQL Dump (Fallback)
SET CONSTRAINTS ALL DEFERRED;

-- Table: User
TRUNCATE TABLE "users" CASCADE;
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (6, 9, 'Admin Cocody', 'admin_cocody@monecole.ci', '$2b$10$z77FBVyVYn45i5blaZOg.eoaDvFy2CpLcpA7pS/xae2a0jIck1dpi', 'admin', NULL, 0, 1, '2026-08-05T18:15:52.504Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (1, 9, 'Professeur Koffi', 'koffi_cocody_1785950690672@monecole.ci', '$2b$10$RDk.rB25afwwkQ2SyDRX4e4sB.wv45qWtwyAZEBHMdXWSTw1AsMV6', 'teacher', 'Mathématiques', 0, 1, '2026-08-05T17:25:24.840Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2, 9, 'Professeur Konan', 'konan_cocody_1785950690672@monecole.ci', '$2b$10$RDk.rB25afwwkQ2SyDRX4e4sB.wv45qWtwyAZEBHMdXWSTw1AsMV6', 'teacher', 'Français', 0, 1, '2026-08-05T17:25:25.441Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2287, 9, 'Traoré Mamadou', 'mamadou.traore@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:15.388Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2288, 9, 'Koné Fatou', 'fatou.kone@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:15.655Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2289, 9, 'Bamba Ibrahim', 'ibrahim.bamba@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:15.957Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2290, 9, 'Coulibaly Aminata', 'aminata.coulibaly@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:16.241Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2286, 9, 'Kouamé Aya', 'aya.kouame@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:14.862Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2291, 9, 'Diallo Moussa', 'moussa.diallo@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:16.508Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2292, 9, 'Ouattara Mariam', 'mariam.ouattara@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:16.811Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2293, 9, 'Touré Seydou', 'seydou.toure@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:17.126Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2294, 9, 'Yao Adjoua', 'adjoua.yao@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:17.412Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2295, 9, 'Koffi Kouadio', 'kouadio.koffi@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:17.735Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2296, 9, 'Aka Marie-Claire', 'marie.aka@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:18.031Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2297, 9, 'N''Guessan Yves', 'yves.nguessan@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:18.308Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2298, 9, 'Aké Sandrine', 'sandrine.ake@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:18.575Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2299, 9, 'Dosso Abdoulaye', 'abdoulaye.dosso@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:18.859Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2300, 9, 'Gbagbo Christelle', 'christelle.gbagbo@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:19.127Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2301, 9, 'Soro Lacina', 'lacina.soro@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:19.380Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2302, 9, 'Diarrassouba Aïcha', 'aicha.diarrassouba@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:19.732Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2303, 9, 'Konan Jean-Baptiste', 'jb.konan@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:20.042Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2304, 9, 'Diabaté Rokia', 'rokia.diabate@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:20.348Z');
INSERT INTO "users" ("id", "id_ecole", "nom", "email", "password", "role", "matiere", "points", "niveau", "created_at") VALUES (2305, 9, 'Fofana Issouf', 'issouf.fofana@monecole.ci', '$2b$10$placeholder_hash_for_test_students', 'student', NULL, 0, 1, '2026-08-06T23:30:20.610Z');

-- Table: Class
TRUNCATE TABLE "classes" CASCADE;
INSERT INTO "classes" ("id", "id_ecole", "nom", "niveau", "created_at") VALUES (1, 9, 'Terminale A', 'Secondaire', '2026-08-05T17:25:23.613Z');
INSERT INTO "classes" ("id", "id_ecole", "nom", "niveau", "created_at") VALUES (2, 9, 'Terminale C', 'Secondaire', '2026-08-05T17:25:24.225Z');
INSERT INTO "classes" ("id", "id_ecole", "nom", "niveau", "created_at") VALUES (3, 9, '3ème A1', '3ème', '2026-08-06T12:44:59.378Z');

-- Table: Inscription
TRUNCATE TABLE "inscriptions" CASCADE;
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (44, 2286, 1, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (45, 2287, 2, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (46, 2288, 3, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (47, 2289, 1, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (48, 2290, 2, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (49, 2291, 3, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (50, 2292, 1, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (51, 2293, 2, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (52, 2294, 3, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (53, 2295, 1, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (54, 2296, 2, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (55, 2297, 3, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (56, 2298, 1, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (57, 2299, 2, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (58, 2300, 3, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (59, 2301, 1, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (60, 2302, 2, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (61, 2303, 3, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (62, 2304, 1, '2023-2024');
INSERT INTO "inscriptions" ("id", "id_eleve", "id_classe", "annee_scolaire") VALUES (63, 2305, 2, '2023-2024');

-- Table: NotificationEmail
TRUNCATE TABLE "notification_emails" CASCADE;
INSERT INTO "notification_emails" ("id", "to", "subject", "body", "templateName", "status", "sentAt", "errorMessage", "retryCount", "scheduledFor") VALUES (1, 'jean_cocody_1785950690672@monecole.ci', '[MonÉcole+] Reçu de Paiement Certifié - REC-2026-13567', '
      <div style="font-family: Arial, sans-serif; max-width: 700px; margin: auto; padding: 30px; border: 2px solid #e2e8f0; border-radius: 16px; background: #fff; color: #334155;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #3b82f6; padding-bottom: 20px;">
          <div>
            <h1 style="color: #1e3a8a; margin: 0; font-size: 24px; font-weight: 800;">REÇU DE PAIEMENT CERTIFIÉ</h1>
            <p style="margin: 5px 0 0 0; font-size: 13px; color: #64748b; font-weight: bold;">N° unique : REC-2026-13567</p>
          </div>
          <div style="text-align: right;">
            <h2 style="margin: 0; color: #3b82f6; font-size: 16px;">Lycée Moderne de Cocody</h2>
            <p style="margin: 5px 0 0 0; font-size: 12px; color: #64748b;">Généré le 06/08/2026</p>
          </div>
        </div>

        <div style="margin: 30px 0; line-height: 1.8;">
          <p>Le secrétariat général de l''établissement atteste avoir reçu de l''élève <strong>Jean Marc</strong> la somme de :</p>
          <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 12px; padding: 20px; text-align: center; margin: 20px 0;">
            <h3 style="margin: 0; color: #15803d; font-size: 28px; font-weight: 900;">120 000 FCFA</h3>
            <p style="margin: 5px 0 0 0; font-size: 13px; color: #166534; font-weight: bold;">Objet : Frais de scolarite</p>
          </div>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-top: 50px; border-top: 1px solid #e2e8f0; pt: 20px;">
          <div style="font-size: 11px; color: #94a3b8; max-width: 400px;">
            <p style="margin: 0; font-weight: bold; color: #64748b;">🔒 Sécurité & Authenticité</p>
            <p style="margin: 5px 0 0 0; break-all: yes; font-family: monospace;">SHA256: b806f3757399c9777e2c66a68831115e84e5c39d352ba4a1a68308aa1372c446</p>
            <p style="margin: 5px 0 0 0;">Scannez le QR Code pour vérifier l''originalité de cette pièce sur le portail public.</p>
          </div>
          <div>
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANQAAADUCAYAAADk3g0YAAAAAklEQVR4AewaftIAAApySURBVO3BQY7YSHAAwUxi/v/ltI51aoBgj7S2K8L+YK11xcNa65qHtdY1D2utax7WWtc8rLWueVhrXfOw1rrmYa11zcNa65qHtdY1D2utax7WWtc8rLWueVhrXfOw1rrmh49U/qaKE5WTihOVqeINlaliUpkqJpWpYlKZKm5S+aLiDZWpYlL5myq+eFhrXfOw1rrmYa11zQ+XVdykcpPKVDFVnKhMFTdVTCpTxaTyRsWkMlV8oTJVTCpTxRsVN6nc9LDWuuZhrXXNw1rrmh9+mcobFW+oTBWTyhsqJxVvqEwVb1S8UXGicqJyUjGp/Esqb1T8poe11jUPa61rHtZa1/zwf4zKVDGpvFExqUwVX6i8UTFVTCpvVJyoTCpTxaTyhspU8b/Zw1rrmoe11jUPa61rfvg/TuVEZaqYVN6oOFH5QuWNijdUTiomlaliUvn/5GGtdc3DWuuah7XWNT/8soq/qeILlaniC5WpYlKZKt5QmSomlTcq3qg4qfhNFf8lD2utax7WWtc8rLWu+eEylf8SlaliUpkqJpWpYlKZKm5SmSq+qJhUTlSmikllqphUpopJZao4Ufkve1hrXfOw1rrmYa11zQ8fVfyXVZxUTCpTxaQyVUwqN1W8oXKicqIyVfxLFf+bPKy1rnlYa13zsNa6xv7gA5WpYlK5qeINlZOKSeWkYlKZKiaVqWJSuaniN6lMFb9J5aaK3/Sw1rrmYa11zcNa6xr7g4tUvqh4Q2WqeEPlpGJS+U0VJypTxaQyVUwqU8Wk8kbFGyonFW+o3FTxxcNa65qHtdY1D2uta374SOWLihOVqWKqOFE5qZhUvqiYVKaKLyomlROVLyomlROVk4pJZVJ5o2JSmSomlanipoe11jUPa61rHtZa19gfXKQyVZyoTBUnKl9UvKFyUvGGyknFFyr/UsWk8kXFpHJSMalMFb/pYa11zcNa65qHtdY19gd/kcpJxaTyRsWkMlVMKm9UTCpvVEwqN1VMKlPFicobFTepTBW/SWWq+OJhrXXNw1rrmoe11jU/XKYyVUwVk8qkMlWcqJxUTCpTxaQyVZxUTCpTxaTyRsUbKlPFGxWTym9SeUNlqphUTip+08Na65qHtdY1D2uta+wP/iKVk4pJ5aRiUpkqJpWTikllqphUpopJZaqYVP6likllqjhReaNiUpkqJpWTijdUpoqbHtZa1zysta55WGtd88NHKl9UTCpTxRcqU8VNFV9UTCpTxRcqU8WkclPFpHJSMalMFZPKpPJGxaQyVXzxsNa65mGtdc3DWuuaH/6yiknlROWLiknljYpJ5b9EZaqYKiaVqWJSOVGZKm6qmFSmipsqbnpYa13zsNa65mGtdY39wUUqU8WJylRxonJS8YbKGxWTyknFpDJV/E0qU8Wk8kbFGypvVHyh8kbFFw9rrWse1lrXPKy1rrE/+EBlqphUbqr4TSpTxaRyUjGpTBWTylRxovJFxRcqU8Wk8kbFpPJFxYnKVHHTw1rrmoe11jUPa61rfvio4o2KSeWkYlKZKk5UpopJZaqYVE4qJpWpYlKZKiaVqWKq+ELlpGJSOVGZKk5U3qiYVN5QOVGZKr54WGtd87DWuuZhrXWN/cEHKicVk8rfVHGiclIxqUwVk8pJxaTymyreUDmpeENlqphUbqo4UTmp+OJhrXXNw1rrmoe11jU/XFYxqUwVk8pU8YbKVDGpvFHxhspUcaJyUvGGylTxhsobKlPFpDJVTConFW+oTConFZPKTQ9rrWse1lrXPKy1rvnhP05lqripYlI5qZhUJpWp4guVqeJE5Y2KN1QmlaliUvlCZao4qZhUJpWp4qaHtdY1D2utax7WWtf88FHFpDJVTCpvVLyhclIxqZxUTCpTxW+q+KLiROWNiknljYpJ5aTiDZU3VKaKLx7WWtc8rLWueVhrXWN/8IHKf0nFv6QyVZyo/KaKL1ROKk5U/qWKSWWquOlhrXXNw1rrmoe11jU/XFbxhspJxaRyojJVTCpTxaTyRcWk8kbFpDJVTCr/ZRV/k8pJxaQyVXzxsNa65mGtdc3DWusa+4O/SOWLijdUpopJZap4Q+Wk4kRlqjhRmSomlZOKSeWkYlL5TRUnKlPFpPJGxU0Pa61rHtZa1zysta6xP/hAZaqYVN6o+ELljYo3VE4qJpWp4iaVk4pJ5aRiUpkqJpWp4kRlqphU/qaKmx7WWtc8rLWueVhrXWN/cJHKVDGpfFFxonJS8YbKVHGiMlWcqEwVJyonFZPKVHGi8kbFpDJVfKEyVUwqJxWTylRx08Na65qHtdY1D2uta364rGJSOamYVKaK36RyUjGpTBUnKlPFVDGpvFExqUwVk8pU8YXKVHGiMlV8UTGpTCpTxaQyVXzxsNa65mGtdc3DWusa+4MPVL6omFTeqJhU3qj4QmWqeEPlpOILlaniC5WpYlJ5o+INlaliUnmj4qaHtdY1D2utax7WWtfYH1yk8kbFGypvVNykMlVMKicVb6i8UTGpfFFxonJSMalMFScqJxWTyhcVXzysta55WGtd87DWuuaHv6ziROWk4jep/EsqU8UXFV+onFScqEwVJyonFZPKScXf9LDWuuZhrXXNw1rrmh8+UpkqJpUTlaniDZWpYlJ5o+JE5QuVk4pJZaqYVKaKL1RuqjhRmSomlUllqphU3lCZKr54WGtd87DWuuZhrXWN/cE/pDJVTCpTxaTyN1WcqJxUvKFyUjGpfFFxonJSMal8UTGpTBWTyknFb3pYa13zsNa65mGtdY39wUUqX1ScqJxUTCpvVJyonFRMKjdVTCpTxYnKGxUnKlPFicpJxaQyVbyhMlX8poe11jUPa61rHtZa19gffKAyVZyonFRMKlPFpPJGxYnKScWJyknFpPI3VbyhMlW8oTJVTCq/qeJvelhrXfOw1rrmYa11zQ8fVbxR8UbFGxUnKjepTBVfVLyhMlX8JpU3KiaVk4o3VE5U3qj44mGtdc3DWuuah7XWNT98pPI3VUwVk8oXFScqb6h8oTJVnKicVEwqU8VU8YXKFypTxUnFpHJScdPDWuuah7XWNQ9rrWt+uKziJpUTlb+pYlJ5o2JSOal4o+JE5URlqjhRmSpuqnhD5V96WGtd87DWuuZhrXXND79M5Y2Kmyq+UPmi4g2VL1TeqJhUTlSmiknlC5WbKv6mh7XWNQ9rrWse1lrX/PD/nMpUcVJxojJVnFScqEwVk8pUcZPKFxVfqLxRMam8UfHFw1rrmoe11jUPa61rfvg/pmJSmSreqDhROVH5ouKk4kRlqjipOFF5Q2WqmFROKn5TxU0Pa61rHtZa1zysta754ZdV/KaKk4pJZaqYVKaKk4pJ5YuKE5WpYlKZKk5U3qiYVG6qOFH5ouI3Pay1rnlYa13zsNa65ofLVP4mlaniDZUTlaliUjmpmFSmikllqjhReUNlqnhDZar4TSonFW+oTBU3Pay1rnlYa13zsNa6xv5grXXFw1rrmoe11jUPa61rHtZa1zysta55WGtd87DWuuZhrXXNw1rrmoe11jUPa61rHtZa1zysta55WGtd87DWuuZ/AJ4Tq7gseiTjAAAAAElFTkSuQmCC" style="width: 110px; height: 110px; border: 1px solid #cbd5e1; border-radius: 8px; padding: 4px;" alt="QR Verification" />
          </div>
        </div>
      </div>
    ', 'payment_received', 'sent', '2026-08-05T23:34:39.811Z', NULL, 0, NULL);
INSERT INTO "notification_emails" ("id", "to", "subject", "body", "templateName", "status", "sentAt", "errorMessage", "retryCount", "scheduledFor") VALUES (2, 'jean_cocody_1785950690672@monecole.ci', '[MonÉcole+] Reçu de Paiement Certifié - REC-2026-47766', '
      <div style="font-family: Arial, sans-serif; max-width: 700px; margin: auto; padding: 30px; border: 2px solid #e2e8f0; border-radius: 16px; background: #fff; color: #334155;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #3b82f6; padding-bottom: 20px;">
          <div>
            <h1 style="color: #1e3a8a; margin: 0; font-size: 24px; font-weight: 800;">REÇU DE PAIEMENT CERTIFIÉ</h1>
            <p style="margin: 5px 0 0 0; font-size: 13px; color: #64748b; font-weight: bold;">N° unique : REC-2026-47766</p>
          </div>
          <div style="text-align: right;">
            <h2 style="margin: 0; color: #3b82f6; font-size: 16px;">Lycée Moderne de Cocody</h2>
            <p style="margin: 5px 0 0 0; font-size: 12px; color: #64748b;">Généré le 06/08/2026</p>
          </div>
        </div>

        <div style="margin: 30px 0; line-height: 1.8;">
          <p>Le secrétariat général de l''établissement atteste avoir reçu de l''élève <strong>Jean Marc</strong> la somme de :</p>
          <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 12px; padding: 20px; text-align: center; margin: 20px 0;">
            <h3 style="margin: 0; color: #15803d; font-size: 28px; font-weight: 900;">120 000 FCFA</h3>
            <p style="margin: 5px 0 0 0; font-size: 13px; color: #166534; font-weight: bold;">Objet : Frais de scolarite</p>
          </div>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-top: 50px; border-top: 1px solid #e2e8f0; pt: 20px;">
          <div style="font-size: 11px; color: #94a3b8; max-width: 400px;">
            <p style="margin: 0; font-weight: bold; color: #64748b;">🔒 Sécurité & Authenticité</p>
            <p style="margin: 5px 0 0 0; break-all: yes; font-family: monospace;">SHA256: 26b6d2e64d373fb5af01f058b91ae77b4dba978ee3df4872885df9207b626eea</p>
            <p style="margin: 5px 0 0 0;">Scannez le QR Code pour vérifier l''originalité de cette pièce sur le portail public.</p>
          </div>
          <div>
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANQAAADUCAYAAADk3g0YAAAAAklEQVR4AewaftIAAAqGSURBVO3BQY7gRpIAQXei/v9l3z7GKQGCWS1pNszsD9ZaVzysta55WGtd87DWuuZhrXXNw1rrmoe11jUPa61rHtZa1zysta55WGtd87DWuuZhrXXNw1rrmoe11jUPa61rfvhI5W+qOFE5qfhNKlPFpDJVTCpTxaQyVUwqU8UbKjdVnKhMFZPK31TxxcNa65qHtdY1D2uta364rOImlTcqTlSmiknlpGJSualiUpkqJpWpYlKZKiaVqeI3qUwVb1TcpHLTw1rrmoe11jUPa61rfvhlKm9UvKFyU8WkMqm8oTJVvFFxk8qJyknFpHJS8ZtU3qj4TQ9rrWse1lrXPKy1rvlhHVVMKlPFpPKGyhsVU8UXFScqk8pUMam8oTJV/Jc9rLWueVhrXfOw1rrmh/8xFScqJyonFScVJypfqLxR8YbKScWkMlVMKv+fPKy1rnlYa13zsNa65odfVvE3qUwVX1RMKlPFicpUMalMFW+onKi8UXGiMlWcVPymin+Th7XWNQ9rrWse1lrX/HCZyj+pYlKZKiaVqWJSmSomlaniJpWp4qRiUpkqJpUTlaliUpkqJpWpYlKZKk5U/s0e1lrXPKy1rnlYa13zw0cV/yUqU8WkMlWcVEwqN1W8oXKicqIyVfyTKv5LHtZa1zysta55WGtdY3/wgcpUMancVHGi8psqJpWpYlKZKiaVmyp+k8pU8ZtUbqr4TQ9rrWse1lrXPKy1rrE/uEjljYo3VL6oOFGZKiaVv6niROWkYlKZKiaVNyreUDmpeEPlpoovHtZa1zysta55WGtd88NlFZPKicpUMal8UTGp/KaKSWWqOFE5UZkqJpVJ5YuKSeVE5aRiUplU3qiYVKaKSWWquOlhrXXNw1rrmoe11jX2B/8glaniROWkYlL5TRVvqLxR8YbKScWJyhcVk8oXFScqU8WkMlX8poe11jUPa61rHtZa1/zwD6s4UfmbKiaVqeJE5aRiUpkqJpWTiqliUnmj4kRlqjipeEPlRGWqOKk4UZkqvnhYa13zsNa65mGtdc0PH6mcVJyoTBVTxYnKpDJVfFFxonJSMamcqEwVk8qJylQxqUwVJyq/SeWNihOVk4rf9LDWuuZhrXXNw1rrmh8+qphUTlTeUDmpmFTeUDmpeKNiUpkqJpWp4qRiUjlReUNlqjhReaPipGJSOamYKk5UpoqbHtZa1zysta55WGtd88M/rGJSmSpOVE5UpoqbKr6omFSmiknljYoTlZsqJpWTikllqphUJpV/k4e11jUPa61rHtZa1/zwkcpUcVJxUjGpfFExqXyhMlVMKm+oTBUnFScqJypTxaRyojJV3FQxqUwV/2YPa61rHtZa1zysta754R+mMlVMFScqU8VJxaQyVUwqX1RMKlPFv5nKFxWTyhsVX6i8UfHFw1rrmoe11jUPa61r7A8+UHmjYlKZKiaVmypOVE4qJpU3KiaVqeJE5aRiUpkqvlCZKiaVNyomlb+p4qaHtdY1D2utax7WWtfYH3yg8kbFpHJSMal8UTGpnFR8oXJSMalMFW+ofFExqbxRcaIyVbyhclIxqbxR8cXDWuuah7XWNQ9rrWvsDy5S+SdVvKHyRsUbKlPFpHJTxaQyVZyonFS8oTJVTCo3VZyonFR88bDWuuZhrXXNw1rrmh8+UpkqJpU3Kt5QOVE5qfhC5aRiUjmpeEPlpOJE5Q2VqWJSmSomlZOKN1QmlZOKSeWmh7XWNQ9rrWse1lrX/PDLKiaVN1Smii8qTlROKv4mlaniRGWqmFSmijdUJpWpYlL5QmWqOKmYVCaVqeKmh7XWNQ9rrWse1lrX/PBRxaQyVUwVk8pJxRsqb6icVJxU/KaKmyomlTcqJpU3KiaVk4o3VN5QmSq+eFhrXfOw1rrmYa11jf3BByr/JhUnKlPFTSpTxYnKb6r4QuWk4kTln1QxqUwVNz2sta55WGtd87DWuuaHyyreUDmpOFE5UZkqJpWbKiaVNyomlaliUvk3q3hDZap4Q+WkYlKZKr54WGtd87DWuuZhrXXND3+ZyhsqU8VUMamcqEwVk8pJxaTyRsWkclIxqUwVk8qkMlVMKicVk8qkclPFicpUcaJyUnHTw1rrmoe11jUPa61rfrhM5YuKN1TeqJhUpooTlZsq3qiYVE4qJpWTikllqphUpooTlaliUnlD5d/kYa11zcNa65qHtdY1P1xW8YbKicpUcVIxqXyhMlW8UXGiMlWcqJxUTConFZPKicpUMalMFVPFScWkMlVMKicVk8qkMlV88bDWuuZhrXXNw1rrGvuDX6QyVUwqJxV/k8pUMamcVHyh8kbFpDJVTCpTxaTyRcWJylRxojJVnKh8UfHFw1rrmoe11jUPa61rfvhI5aRiUpkqJpVJZao4UTmp+KLiJpWTihOVqWJSeaPiRGWqmFRuqphUpoo3Kn7Tw1rrmoe11jUPa61rfrisYlI5UTmp+KLiROVE5aaKqeJEZap4o2JSmVROKqaKSeWkYlJ5Q+W/5GGtdc3DWuuah7XWNT9cpjJVvKEyqUwVJxVvVEwqJxUnKl+oTBVfqEwVb6icVJyoTBUnKicVk8pJxd/0sNa65mGtdc3DWuuaH36ZylQxqUwVb6hMFZPKFxWTyhcqJxWTylRxojJVvKFyU8WJylQxqUwqU8Wk8obKVPHFw1rrmoe11jUPa61rfvio4jepTBVvVEwqJxWTylQxqZxUnKi8oTJVnKi8UXGiMqlMFZPKGypTxaTyhspUMVXc9LDWuuZhrXXNw1rrmh8uU7mpYlL5TSpfVLxRMamcVEwqJxWTyonKVDFVTConFZPKScWkMlWcVEwqf9PDWuuah7XWNQ9rrWvsDz5QmSpOVE4qJpWp4kTlN1VMKlPFGyp/U8UbKlPFicpUcaLymyr+poe11jUPa61rHtZa1/zwUcUbFW9UnKicVLyhcpPKVHFS8YbKVDGp3KQyVbyhclLxhsqJyhsVXzysta55WGtd87DWuuaHj1T+poqpYlI5UZkqpoo3Kt5QeUNlqnij4kRlqpgqJpWTiknlC5Wp4qRiUjmpuOlhrXXNw1rrmoe11jU/XFZxk8qJylQxqZyoTBVvqEwVU8WJyknFTSonKlPFVDGpTBU3Vbyh8k96WGtd87DWuuZhrXXND79M5Y2KL1SmikllqjhR+UJlqjhR+ULljYpJ5URlqphUvlC5qeJvelhrXfOw1rrmYa11zQ//z1R8UXGi8kbFicpUMalMFTepfFHxhcobFZPKVDGpTBVfPKy1rnlYa13zsNa65of/cSpfVJyoTBWTyqTyRsWk8obKVHFScaLyhspUMamcVNykMlXc9LDWuuZhrXXNw1rrmh9+WcVvqjhRmSpOVCaVqWKqmFSmiknlpOKNikllqvhCZaqYVN5QmSreUPmi4jc9rLWueVhrXfOw1rrmh8tU/iaVqeINlZOKNyreqJhUpooTlTdUpopJ5URlqvhCZaqYVE4q3lCZKm56WGtd87DWuuZhrXWN/cFa64qHtdY1D2utax7WWtc8rLWueVhrXfOw1rrmYa11zcNa65qHtdY1D2utax7WWtc8rLWueVhrXfOw1rrmYa11zf8BjmyPGkauftUAAAAASUVORK5CYII=" style="width: 110px; height: 110px; border: 1px solid #cbd5e1; border-radius: 8px; padding: 4px;" alt="QR Verification" />
          </div>
        </div>
      </div>
    ', 'payment_received', 'sent', '2026-08-06T00:00:09.966Z', NULL, 0, NULL);
INSERT INTO "notification_emails" ("id", "to", "subject", "body", "templateName", "status", "sentAt", "errorMessage", "retryCount", "scheduledFor") VALUES (3, 'info1sanahotel@gmail.com', '[MonÉcole+] Bienvenue sur notre plateforme !', '
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Bienvenue sur MonÉcole+</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, ''Segoe UI'', Roboto, Helvetica, Arial, sans-serif; background-color: #f8fafc; color: #1e293b; margin: 0; padding: 0; }
          .container { max-width: 600px; margin: 20px auto; background: #ffffff; border-radius: 24px; border: 1px solid #e2e8f0; overflow: hidden; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.05); }
          .header { background: linear-gradient(135deg, #2563eb, #4f46e5); color: #ffffff; padding: 32px; text-align: center; }
          .header h1 { margin: 0; font-size: 24px; font-weight: 800; letter-spacing: -0.05em; }
          .content { padding: 32px; line-height: 1.6; }
          .content h2 { color: #0f172a; margin-top: 0; font-size: 18px; font-weight: 700; }
          .btn { display: inline-block; padding: 12px 24px; background-color: #2563eb; color: #ffffff !important; text-decoration: none; border-radius: 12px; font-weight: bold; font-size: 14px; margin-top: 20px; text-align: center; }
          .footer { background-color: #f1f5f9; padding: 20px; text-align: center; font-size: 12px; color: #64748b; border-top: 1px solid #e2e8f0; }
          .footer a { color: #2563eb; text-decoration: none; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>MonÉcole+</h1>
          </div>
          <div class="content">
            
    <h2>Bienvenue Abou Traoré !</h2>
    <p>Nous sommes ravis de vous compter parmi les utilisateurs de <strong>MonÉcole+</strong>.</p>
    <p>Votre compte a été créé avec le rôle : <strong style="text-transform: capitalize;">Élève</strong>.</p>
    <p>Découvrez dès maintenant votre nouvel espace et gérez vos activités scolaires en toute simplicité.</p>
    <a href="https://monecoleplus.com/login" class="btn">Commencer</a>
  
          </div>
          <div class="footer">
            <p>Cet email a été envoyé par <strong>MonÉcole+</strong>.</p>
            <p>© 2026 MonÉcole+. Tous droits réservés.</p>
          </div>
        </div>
      </body>
    </html>
  ', 'welcome', 'sent', '2026-08-06T13:39:34.245Z', NULL, 0, NULL);

-- Table: NotificationWhatsapp
TRUNCATE TABLE "notification_whatsapps" CASCADE;
INSERT INTO "notification_whatsapps" ("id", "to", "message", "templateName", "status", "sentAt", "errorMessage", "retryCount", "scheduledFor") VALUES (1, 'whatsapp:+2250700000000', '✅ *MonÉcole+ | Reçu de Paiement*

Bonjour, le paiement de *120 000 FCFA* pour l''élève *Jean Marc* (Frais de scolarite) a été validé avec succès.

N° unique de reçu : *REC-2026-13567*

SHA256 : b806f3757399c9777e2c66a68831115e84e5c39d352ba4a1a68308aa1372c446', 'payment_received', 'sent', '2026-08-05T23:34:41.133Z', NULL, 0, NULL);
INSERT INTO "notification_whatsapps" ("id", "to", "message", "templateName", "status", "sentAt", "errorMessage", "retryCount", "scheduledFor") VALUES (2, 'whatsapp:+2250700000000', '✅ *MonÉcole+ | Reçu de Paiement*

Bonjour, le paiement de *120 000 FCFA* pour l''élève *Jean Marc* (Frais de scolarite) a été validé avec succès.

N° unique de reçu : *REC-2026-47766*

SHA256 : 26b6d2e64d373fb5af01f058b91ae77b4dba978ee3df4872885df9207b626eea', 'payment_received', 'sent', '2026-08-06T00:00:11.340Z', NULL, 0, NULL);
INSERT INTO "notification_whatsapps" ("id", "to", "message", "templateName", "status", "sentAt", "errorMessage", "retryCount", "scheduledFor") VALUES (3, 'whatsapp:+2250141551665', '🔴 *MonÉcole+ | Notification d''Absence*

Bonjour, nous vous informons que l''élève *Abou Traoré* a été signalé absent le *25 Octobre 2026*.

Merci de contacter l''administration de l''établissement au plus vite pour justifier cette absence.', 'custom_override', 'sent', '2026-08-06T12:40:17.062Z', NULL, 0, NULL);

-- Table: BackupLog
TRUNCATE TABLE "backup_logs" CASCADE;
INSERT INTO "backup_logs" ("id", "filename", "backupType", "size", "status", "createdAt", "errorMessage") VALUES (1, 'db_backup_1785972885221.enc', 'database', '3.55 KB', 'success', '2026-08-05T23:34:45.228Z', NULL);
INSERT INTO "backup_logs" ("id", "filename", "backupType", "size", "status", "createdAt", "errorMessage") VALUES (2, 'db_backup_1785974415520.enc', 'database', '5.20 KB', 'success', '2026-08-06T00:00:15.523Z', NULL);
INSERT INTO "backup_logs" ("id", "filename", "backupType", "size", "status", "createdAt", "errorMessage") VALUES (3, 'db_backup_1786058648726.sql.gz', 'database', '6.30 KB', 'success', '2026-08-06T23:24:08.740Z', NULL);
INSERT INTO "backup_logs" ("id", "filename", "backupType", "size", "status", "createdAt", "errorMessage") VALUES (4, 'db_backup_1786058929065.sql.gz', 'database', '6.44 KB', 'success', '2026-08-06T23:28:49.072Z', NULL);

-- Table: SystemLog
TRUNCATE TABLE "system_logs" CASCADE;
